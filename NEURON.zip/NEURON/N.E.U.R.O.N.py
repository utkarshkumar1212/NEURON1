import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')

engine.setProperty('voices', voices[0].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()
    
def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning!")

    elif hour>=12 and hour<18:
        speak("Good Afternoon!")

    else:
        speak("Good evening!")
    print("I am NEURON or Neurodiversity Enhanced Understanding & Responsive Online Network and I am created by Cryptic. Please tell me how may i help you")
    speak("I am NEURON or Neurodiversity Enhanced Understanding & Responsive Online Network and I am created by Cryptic. Please tell me how may i help you")
    

def takeCommand():
    #it takes audio input from the user and returns string output 

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening....")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing....")
        query = r.recognize_google(audio, language= 'en-in')
        print(f"User Said: {query}\n")

    except Exception as e:
        
        print("Say that again Please....")  
        return "None"   
    return query

if __name__=='__main__':
    wishMe()
    while True:
        query = takeCommand().lower()
        # logic for executing tasks based on query
        if 'wikipedia' in query:
            speak('Searching Wikipedia....')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences= 5)
            speak("According To Wikipedia")
            print(results)
            speak(results)

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")
            speak("Opening Youtube")

        elif 'open discord' in query:
            webbrowser.open("discord.com")
            speak("Opening Discord")

        elif 'open webtoon' in query:
            webbrowser.open("https://www.webtoons.com/en/")
            speak("Opening Webtoon")

        elif 'open anime' in query:
            webbrowser.open("zoro.to")
            speak("opening your favourable anime streanimg site")
        
        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"Sir. The time is {strTime}")
            print(strTime)

        elif 'open chrome' in query:
            ChromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
            os.startfile(ChromePath)
            speak("Opening Google Chrome")

        elif 'open bing' in query:
            BingPath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
            os.startfile(BingPath) 
            speak("Opening Microsoft Edge")
        