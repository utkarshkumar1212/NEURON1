const userMessage = document.getElementById('user-message');
const botMessage = document.getElementById('bot-message');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// Set up Wit.ai API key
const witApiKey = 'YOUR_WIT_API_KEY_HERE';

sendButton.addEventListener('click', () => {
    const userText = userInput.value.trim();
    if (userText !== '') {
        userMessage.textContent = `You: ${userText}`;
        userInput.value = '';

        // Send request to Wit.ai API
        fetch(`https://api.wit.ai/message?v=20220526&q=${userText}`, {
            headers: {
                'Authorization': `Bearer ${witApiKey}`,
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            const intent = data.entities.intent[0].value;
            const responseText = getResponse(intent);
            botMessage.textContent = `Bot: ${responseText}`;
        })
        .catch(error => console.error(error));
    }
});

// Define responses based on intent
function getResponse(intent) {
    switch (intent) {
        case 'greeting':
            return 'Hello! How can I help you today?';
        case 'goodbye':
            return 'Goodbye! It was nice chatting with you.';
        case 'help':
            return 'I can assist you with any questions or topics you\'d like to discuss.';
        default:
            return 'I didn\'t understand that. Can you please rephrase?';
    }
}